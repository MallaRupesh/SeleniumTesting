''' Nessecary packages and drivers to run this file :
->Geckodriver ,
->html-testRunner,
->All the packages imported below .
'''
#importing packages
import time
import unittest
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import timeit
import urllib3
import requests
from urllib import request
import logging
import HtmlTestRunner
#for logs with time
logging.basicConfig(filename="test.log",format='%(asctime)s:%(levelname)s:%(message)s',datefmt='%m/%d/%Y:%S %p',level=logging.DEBUG)
#To get the response of the Http
resp=request.urlopen("https://www.atg.party")
print("HTTP response =",resp.code)
t=str(requests.get("https://www.atg.party").elapsed.total_seconds())
print("Time of response of website:"+t+"sec")
#testing starts here
class ATG_Test(unittest.TestCase):
    @classmethod
    def setUp(cls):
        #Please change your path as in your computer
        cls.driver=webdriver.Firefox(executable_path='/home/rupesh/PycharmProjects/selenium/geckodriver-v0.26.0-linux64/geckodriver')
        cls.driver.maximize_window()
        time.sleep(5)
        logging.debug("Opening the website ")

    #test for logging in and posting
    def test_loginbutton(self):
        self.driver.get("https://www.atg.party")
        time.sleep(4)
        login = self.driver.find_element_by_xpath("/html/body/div[1]/div/header/div[1]/nav/div[2]/ul/li[7]/a")
        login.click()
        time.sleep(3)
        email = self.driver.find_element_by_name('email')
        email.click()
        email.send_keys("wiz_saurabh@rediffmail.com")
        password = self.driver.find_element_by_name('password')
        password.click()
        password.send_keys("Pass@123")
        signin = self.driver.find_element_by_xpath("//*[@id='reset_button']")
        signin.click()
        time.sleep(10)
        self.driver.get("https://www.atg.party/article")
        description = self.driver.find_element_by_xpath("/html/body/div[1]/div[2]/div[4]/section/div[1]/div/form/div[2]/div[2]/div[1]/div[1]/div[2]/div")
        description.send_keys('Test Description')
        title = self.driver.find_element_by_name('title')
        title.send_keys('Test title')
        #Please change the directory of the image
        photo = self.driver.find_element_by_xpath("//*[@id='article_pic']").send_keys("D:\\unnamed.jpg")
        post = self.driver.find_element_by_xpath("//*[@id='featurebutton']")
        post.click()
        lastpage_url = self.driver.current_url
        print(lastpage_url)

    @classmethod
    def tearDown(cls):
        print("Test completed ......")



#Please change the directory where you want to get the log reports
if __name__ == '__main__':
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:\\Users\\Admin\\PycharmProjects\\Selenium\\Reports'))


